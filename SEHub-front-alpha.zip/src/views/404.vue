<template>
	<div>
		<div class="box">
			404
			<br>
			<span>访问的页面不存在</span>
		</div>
	</div>
</template>
<style lang="stylus" scoped>
// .cnt {
// width: 100%;
// }
.box {
	text-align: center;
	font-size: 2rem;
	color: #909090;
	margin-top: 30px;

	span {
		font-size: 1.125rem;
	}
}
</style>
