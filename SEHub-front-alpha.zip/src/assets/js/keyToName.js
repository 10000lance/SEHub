const DEPARTMENT = {
	Secretary: '秘书部',
    Literary: '文艺部',
    Propaganda: '宣传部',
    Sports: '体育部',
    Media: '新媒体',
    Volunteer: '志愿者者',
    Research: '调研部',
    Life: '生活部',
    Quality: '素拓部',
    Academic: '学术部',
    Organization: '组织部',
    Relation: '外联部',
    StandingCommittee: '常委',			
};

const POSITION = {
	Minister: '部长',
	Staff: '干事',
	StandingCommittee: '常委',
};

const AUTHORITIEES = {
	Etiquette: '审批礼仪申请表',
	Poster: '审批海报申请表',
	LectureTicket: '审批讲座票申请表',
	Host: '审批主持人申请表',
};

const TICKETTYPE = {


};

export {
	DEPARTMENT,
	POSITION,
	AUTHORITIEES,
	TICKETTYPE,
};