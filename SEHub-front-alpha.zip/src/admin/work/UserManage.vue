<template>
  <div>用户管理</div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>
<style lang="stylus" scoped src=""></style>
