<template>
	<el-form :model="personData" ref="personInfoForm">
		<div v-for="(value, key) in personData">
			<el-form-item v-if="keyToName(key)" :label="keyToName(key) + ':'" class="apy-item">
				
				<el-input
					v-if="notChange.indexOf(key) !== -1"
					v-model="personData[key]"
					class="apy-input-normal"
					:disabled="true"
				></el-input>
				
				<el-input
					v-else
					v-model="personData[key]"
					class="apy-input-normal"
				></el-input>
			</el-form-item>
		</div>

		<el-form-item label="职责:" class="apy-item">
			<el-checkbox-group v-model="personData.authoritiees">
				<div v-for="authoritiee in authoritieesList">
					<el-checkbox :label="authoritiee">{{authoritieeToName(authoritiee)}}</el-checkbox>
				</div>
			</el-checkbox-group>
		</el-form-item>
	</el-form>
</template>

<script type="text/javascript">
import { POSITION, DEPARTMENT, AUTHORITIEES } from '../../assets/js/keyToName.js';

const KeyToName = {
	studentNumber: '学号',
	name: '姓名',
	department: '所属部门',
	position: '职位',
	phone: '联系电话',
	email: '邮箱',
	// authoritiees: '职责',
};

const AUTHORITIEESLIST = {
	Secretary: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Literary: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Propaganda: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Sports: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Media: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Volunteer: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Research: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Life: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Quality: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Academic: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Organization: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    Relation: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
    StandingCommittee: ['Etiquette', 'Poster', 'LectureTicket', 'Host',],
};

export default {
	props: [
		'personInfo',
	],
	data (){
		return {
			authoritieesList: AUTHORITIEESLIST[this.personInfo.department],

			//不能修改的
			notChange: [
				'department',
				'position',
				'authoritiees',
			]
		};
	},
	methods: {
		keyToName (key){
			// console.log(key);
			return KeyToName[key];
		},
		valueToName (value){
			// console.log(value);
			let p = POSITION[value],
				d = DEPARTMENT[value];
			return p ? p : (d ? d : value);
		},
		//职责键名转换
		authoritieeToName (authoritiee){
			console.log('authoritiee', authoritiee);
			return AUTHORITIEES[authoritiee];
		},
		NameToValue (name){
			for (let changeObj in [POSITION, DEPARTMENT]){
				for (let key in changeObj){
					if (changeObj.hasOwnProperty(key)){
						if (changeObj[key] === name){
							// console.log(key);
							return key;
						}
					}
				}
			}
			return name;
		}
	},
	computed: {
		personData (){
			let data = {};
			for (let key in this.personInfo){
				if (this.personInfo.hasOwnProperty(key)){
					data[key] = this.valueToName(this.personInfo[key]);
				}
			}
			console.log('personData', data);
			return data;
		},
		// authoritiees (){
		// 	let data = [];
		// 	for (let authoritiee of this.personInfo.authoritiees){
		// 		data.push(authoritiee);
		// 	}
		// 	console.log(data);
		// 	return data;
		// },
	},
};
</script>
<!-- <style lang="stylus" scoped src="../../assets/css/other/changeForm.styl"></style> -->
<style lang="stylus">
.apy-item
	padding: 0 10px;
	
.apy-item .el-form-item__label{
	display: block;
	width: 20%;
	font-weight: bold;
}

@media screen and (max-width: 540px){
	.apy-item .el-form-item__label{
		text-align: left;
		width: 100%;
	}
}
.apy-input-normal,
.apy-text-normal
	width 60%
	@media screen and (max-width: 540px)
		width 100%

</style>