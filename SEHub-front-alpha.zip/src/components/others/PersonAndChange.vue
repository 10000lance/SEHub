<template>
	<div>
        <div class="box-content">
        	<transition v-if="!showChangeForm" name="el-fade-in">
	        	<person-info :personInfo="personInfo"></person-info>
	        </transition>
	        <transition v-else name="el-fade-in">
	        	<change-form :personInfo="personInfo" style="margin-top: 12px"></change-form>
	        </transition>
        </div>

        <transition v-if="!showChangeForm" name="el-fade-in">
			<el-button type="primary" class="change-btn" @click="showChange">编辑</el-button>
		</transition>

		<transition v-else name="el-fade-in">
			<div class="btn-group">
				<el-button class="btn" type="primary" @click="postChange">提交</el-button>
				<el-button class="btn" @click="hideChange">取消</el-button>
			</div>
		</transition>
	</div>

</template>
<script type="text/javascript">
import PersonInfo from './PersonInfo.vue';
import ChangeForm from './ChangeForm.vue';

export default {
	props: [
		'personInfo',
	],
	components: {
		'person-info': PersonInfo,
		'change-form': ChangeForm,
	},
	data (){
		return {
			showChangeForm: false,
		};
	},
	// computed: {
	// 	personInfo (){
	// 		return this.$store.state.userInfo;
	// 	}
	// },
	methods: {
		showChange (){
			this.showChangeForm = true;
		},
		hideChange (){
			this.showChangeForm = false;
		},
		postChange (){

		},
	},
};
</script>
<style lang="stylus">
.change-btn
	margin: 30px auto;
	display: block;
	width: 150px;
	@media screen and (max-width: 400px){
		width: 80%;
	}

.btn-group
	margin: auto;
	display: block;
	text-align: center;
	
	.btn
		margin: 15px;
		width: 150px;
		@media screen and (max-width: 400px){
			width: 80%;
		}
</style>