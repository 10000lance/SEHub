<template>
  <div class="matter-container">
    <div class="matter-title">注意事项</div>
    <div class="matter-each" style="color:red;">
      <span>1.&emsp;关于要求</span>
      <br>
      <span>&emsp;&emsp;若对申请的项目有特殊要求，请务必在“特殊要求”中注明。如：“拍照一定要拍到某页PPT”；“拍照时要多拍某某领导”；“拍照时某某时候赞助商会来请多给镜头”；“推送排版时请不要更改文章格式”等</span>
    </div>
    <div class="matter-each">
      <span>2.&emsp;关于申请</span>
      <br>
      <span>&emsp;&ensp;a).拍照、新闻稿：请提前3个工作日提交申请</span>
    </div>
    <div class="matter-each">
      <span>3.&emsp;如果有任何疑惑，可联系新媒体中心部长梁兆璋，手机：13680375111，QQ：1315171497</span>
    </div>
    <div class="matter-each">
      <span>4.&emsp;记者团工作负责人：</span>
      <br>
      <span>&emsp;• 拍照负责人：周瑶, 梁兆璋</span>
      <br>
      <span>&emsp;• 新闻稿负责人：陈楷婷, 唐雨璐</span>
    </div>
    <div class="matter-each">
      <span>5.&emsp;对于不同工作的申请，建议直接向各组的负责人提交，以减少不必要的通知延迟</span>
    </div>
  </div>
</template>
<script>
export default {

}
</script>
<style lang="stylus" scoped src="../../../assets/css/apply/matter.styl"></style>
