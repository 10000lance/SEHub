<template>
  <div class="matter-container">
    <div class="matter-title">注意事项</div>
    <div class="matter-each" style="color:red;">
      <span>1.&emsp;关于要求</span>
      <br>
      <span>&emsp;&emsp;若对申请的项目有特殊要求，请务必在“特殊要求”中注明。如：“推送排版时请不要更改文章格式”；“做视频时请掐掉某某部分”等</span>
    </div>
    <div class="matter-each">
      <span>2.&emsp;关于申请</span>
      <br>
      <span>&emsp;&ensp;a).拍照、写稿：请填写记者团的申请表</span>
      <br>
      <span>&emsp;&ensp;b).公众号推送：请提前4-5个工作日提交申请</span>
      <br>
      <span>&emsp;&ensp;c).视频制作：请提前7-9个工作日提交申请（尽量提前）</span>
    </div>
    <div class="matter-each">
      <span>3.&emsp;如果有任何疑惑，可联系新媒体中心部长梁兆璋，手机：13680375111，QQ：1315171497</span>
    </div>
    <div class="matter-each">
      <span>4.&emsp;新媒体各工作负责人：</span>
      <br>
      <span>&emsp;• 视频负责人：赛炜城, 梁兆璋</span>
      <br>
      <span>&emsp;• 推送负责人：唐雨璐, 陈楷婷</span>
    </div>
    <div class="matter-each">
      <span>5.&emsp;对于不同工作的申请，建议直接向各组的负责人提交，以减少不必要的通知延迟</span>
    </div>
  </div>
</template>
<script>

export default {

}
</script>
<style lang="stylus" scoped src="../../../assets/css/apply/matter.styl"></style>
