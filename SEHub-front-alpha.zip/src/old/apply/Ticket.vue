<template>
  <div>
    <simple-header title="讲座票申请"></simple-header>
  </div>
</template>
<script>
export default {

}
</script>
