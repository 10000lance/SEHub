import axios from 'axios';

export function apiGetDepartment (callback) {
	axios.get('/department')
		.then(res => callback(res))
		.catch(error => {
			console.log(error);
		});
}