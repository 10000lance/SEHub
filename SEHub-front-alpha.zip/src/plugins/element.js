import Vue from 'vue';
// import { Button, Col, Row, NavMenu } from 'element-ui'

// Vue.use(Button)
// Vue.use(Col)
// Vue.use(Row)
// Vue.use(NavMenu)
import ElementUI from 'element-ui';

Vue.use(ElementUI);
