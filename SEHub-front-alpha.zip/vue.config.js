module.exports = {
	assetsDir: 'static',
	port: 8081,
	devServer: {
		proxy: {
			'/api/login': {
				target: 'http://47.101.130.113:8081',
				// target: 'http://192.168.137.1:8081',
				ws: true,
				changeOrigin: true,
				secure: false,
			}
		}
		// proxy: 'http://47.101.130.113:8081',
	}
};
